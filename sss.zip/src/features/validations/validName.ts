export function isValidName(name: string): boolean {
    return name.length >= 3;
  }
  
 