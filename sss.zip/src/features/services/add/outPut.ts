export function addContactResult (isAdded: boolean):void{
    if(isAdded){
      console.log('contact added');    
    } else {
      console.log("contact not added");
    }
}