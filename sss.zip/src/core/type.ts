export interface Contact {
    name: string;
    phone: string;
    tag: string;
}
export interface updateContact {
    preName: string;
    newName: string;
    newPhone: string;
    newTag: string;
}