import path from 'path';
export const filePath = path.join(__dirname, 'contact.json');